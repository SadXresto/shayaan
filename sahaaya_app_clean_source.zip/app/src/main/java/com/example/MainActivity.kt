package com.example

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.ui.theme.SahaayaTheme
import com.example.ui.theme.ThemeMode

// ═══════════════════════════════════════
// DATA MODELS
// ═══════════════════════════════════════

data class SchoolInfo(
    val name: String = "PM Shri Kendriya Vidyalaya No.1, Vasco Da Gama, Goa",
    val phone: String = "+91 832 251 2345",
    val email: String = "kv1vasco@gmail.com",
    val address: String = "Vasco Da Gama, Goa - 403802"
)

data class ChatMessage(
    val id: String,
    val senderName: String,
    val message: String,
    val isFromUser: Boolean,
    val timestamp: String
)

data class Student(
    val id: String,
    val name: String,
    val phone: String,
    val schoolName: String,
    val classSection: String,
    var streak: Int,
    var lastCheckIn: String,
    var checkedInToday: Boolean = false,
    var mood: String = ""
)

data class CheckIn(
    val id: String,
    val studentId: String,
    val studentName: String,
    val studentClass: String,
    val mood: String,
    val factors: List<String>,
    val wantsToTalk: String,
    val timestamp: String
)

data class FriendReport(
    val id: String,
    val reporterId: String,
    val reporterName: String,
    val concernedName: String,
    val concernedPhone: String,
    val classSection: String,
    val concern: String,
    val notes: String = "",
    val urgency: String = "Medium",
    var status: String = "New",
    val timestamp: String
)

data class SupportRequest(
    val id: String,
    val studentId: String,
    val studentName: String,
    val studentClass: String,
    val type: String,
    val notes: String = "",
    var status: String = "New",
    val timestamp: String
)

data class CounsellorCase(
    val id: String,
    val studentId: String,
    val studentName: String,
    val studentClass: String,
    val category: String, // "Follow-up requested", "Conversation requested", "Concern reported", "Needs review"
    var status: String,   // "New", "Under Review", "Scheduled", "Resolved"
    var notes: String,
    val urgency: String = "Medium",
    val timestamp: String
)

// ═══════════════════════════════════════
// REPOSITORY / STATE HOLDER
// ═══════════════════════════════════════

class SahaayaRepository {
    // School Global Information
    var schoolInfo by mutableStateOf(
        SchoolInfo(
            name = "PM Shri Kendriya Vidyalaya No.1, Vasco Da Gama, Goa",
            phone = "+91 832 251 2345",
            email = "kv1vasco@gmail.com",
            address = "Vasco Da Gama, Goa - 403802"
        )
    )

    // Current Active Student (Default Alex Carter)
    var currentStudent by mutableStateOf(
        Student(
            id = "std_alex",
            name = "Alex Carter",
            phone = "+91 98765 43210",
            schoolName = "PM Shri Kendriya Vidyalaya No.1, Vasco Da Gama, Goa",
            classSection = "Class 10 - Section B",
            streak = 7,
            lastCheckIn = "Yesterday",
            checkedInToday = false,
            mood = ""
        )
    )

    var studentSeeds by mutableIntStateOf(120)
    var counsellorName by mutableStateOf("Ms. Sharma")
    val schoolName: String
        get() = schoolInfo.name
    val schoolPhone: String
        get() = schoolInfo.phone
    var counsellorEmail by mutableStateOf("kv1vasco@gmail.com")
    var checkInFrequency by mutableStateOf("Daily")
    var themeMode by mutableStateOf(ThemeMode.SYSTEM)

    // Persistent Chat Messages with Auto-Reply
    val chatMessages = mutableStateListOf(
        ChatMessage(
            id = "msg_1",
            senderName = "Sahaaya Support Assistant",
            message = "Hello! Welcome to Sahaaya Support. How can we help you today? You can ask about school counselling sessions, well-being resources, or confidential check-in questions.",
            isFromUser = false,
            timestamp = "Today, 09:00 AM"
        )
    )

    // Demo Students
    val students = mutableStateListOf(
        Student("s1", "Alex Carter", "+91 98765 43210", "PM Shri Kendriya Vidyalaya No.1, Vasco Da Gama, Goa", "Class 10", 7, "Yesterday", false),
        Student("s2", "Aarav Sharma", "+91 98765 43211", "PM Shri Kendriya Vidyalaya No.1, Vasco Da Gama, Goa", "Class 10", 5, "Today", true, "😟 Not doing well"),
        Student("s3", "Ananya Patel", "+91 98765 43212", "PM Shri Kendriya Vidyalaya No.1, Vasco Da Gama, Goa", "Class 11", 12, "Today", true, "🙂 Okay"),
        Student("s4", "Rohan Verma", "+91 98765 43213", "PM Shri Kendriya Vidyalaya No.1, Vasco Da Gama, Goa", "Class 9", 3, "Today", true, "😔 I need support"),
        Student("s5", "Meera Iyer", "+91 98765 43214", "PM Shri Kendriya Vidyalaya No.1, Vasco Da Gama, Goa", "Class 10", 14, "Today", true, "😊 Good"),
        Student("s6", "Devendra Sen", "+91 98765 43215", "PM Shri Kendriya Vidyalaya No.1, Vasco Da Gama, Goa", "Class 12", 4, "Yesterday", false),
        Student("s7", "Pooja Deshmukh", "+91 98765 43216", "PM Shri Kendriya Vidyalaya No.1, Vasco Da Gama, Goa", "Class 9", 9, "Today", true, "😊 Good"),
        Student("s8", "Priya Nair", "+91 98765 43217", "PM Shri Kendriya Vidyalaya No.1, Vasco Da Gama, Goa", "Class 8", 6, "Today", true, "🙂 Okay"),
        Student("s9", "Kabir Khan", "+91 98765 43218", "PM Shri Kendriya Vidyalaya No.1, Vasco Da Gama, Goa", "Class 7", 8, "Yesterday", false),
        Student("s10", "Vihaan Joshi", "+91 98765 43219", "PM Shri Kendriya Vidyalaya No.1, Vasco Da Gama, Goa", "Class 6", 2, "Today", true, "😊 Good")
    )

    // Check-in history
    val checkIns = mutableStateListOf(
        CheckIn("c1", "s2", "Aarav Sharma", "Class 10 - B", "😟 Not doing well", listOf("Studies", "Home"), "Yes", "Today, 08:30 AM"),
        CheckIn("c2", "s3", "Ananya Patel", "Class 11 - A", "🙂 Okay", listOf("Studies"), "Not right now", "Today, 08:45 AM"),
        CheckIn("c3", "s4", "Rohan Verma", "Class 9 - C", "😔 I need support", listOf("Personal concerns", "Friends"), "Yes", "Today, 09:10 AM"),
        CheckIn("c4", "s5", "Meera Iyer", "Class 10 - A", "😊 Good", listOf("Studies"), "Not right now", "Today, 09:15 AM"),
        CheckIn("c5", "s7", "Pooja Deshmukh", "Class 9 - D", "😊 Good", emptyList(), "Not right now", "Today, 09:25 AM")
    )

    // Friend Reports
    val friendReports = mutableStateListOf(
        FriendReport(
            id = "fr1",
            reporterId = "std_alex",
            reporterName = "Alex Carter",
            concernedName = "Sameer K.",
            concernedPhone = "+91 98111 22334",
            classSection = "Class 10 - Section B",
            concern = "Worried about friend, sudden change in behavior and withdrawing from lunch group.",
            notes = "Seems anxious whenever exams or test results are mentioned.",
            urgency = "Medium",
            status = "New",
            timestamp = "Today, 09:45 AM"
        ),
        FriendReport(
            id = "fr2",
            reporterId = "s5",
            reporterName = "Meera Iyer",
            concernedName = "Rhea Gupta",
            concernedPhone = "+91 98222 33445",
            classSection = "Class 10 - Section A",
            concern = "Friend seems very withdrawn and missed morning classes two days in a row.",
            notes = "Spoke to her yesterday, she mentioned feeling overwhelmed.",
            urgency = "High",
            status = "Under Review",
            timestamp = "Yesterday, 02:15 PM"
        ),
        FriendReport(
            id = "fr3",
            reporterId = "s8",
            reporterName = "Priya Nair",
            concernedName = "Arjun Das",
            concernedPhone = "+91 98333 44556",
            classSection = "Class 8 - Section A",
            concern = "Trouble focusing and looked visibly upset after sports period.",
            notes = "Offered to walk with him to library.",
            urgency = "Low",
            status = "Follow-Up",
            timestamp = "2 days ago"
        )
    )

    // Support Requests
    val supportRequests = mutableStateListOf(
        SupportRequest(
            id = "sr1",
            studentId = "s2",
            studentName = "Aarav Sharma",
            studentClass = "Class 10 - Section B",
            type = "Talk to my counsellor",
            notes = "Discussing study stress and family expectations.",
            status = "New",
            timestamp = "Today, 11:03 AM"
        ),
        SupportRequest(
            id = "sr2",
            studentId = "s4",
            studentName = "Rohan Verma",
            studentClass = "Class 9 - Section C",
            type = "Speak to a trusted adult",
            notes = "Transitioning to senior secondary feels isolating.",
            status = "In Progress",
            timestamp = "Yesterday, 01:22 PM"
        ),
        SupportRequest(
            id = "sr3",
            studentId = "s3",
            studentName = "Ananya Patel",
            studentClass = "Class 11 - Section A",
            type = "Explore support resources",
            notes = "Guidance on sleep hygiene and exam anxiety management.",
            status = "Resolved",
            timestamp = "3 days ago"
        )
    )

    // Counsellor Cases (Needs Review & Follow-up Queue)
    val counsellorCases = mutableStateListOf(
        CounsellorCase(
            id = "case_1023",
            studentId = "s2",
            studentName = "Aarav Sharma",
            studentClass = "Class 10 - Section B",
            category = "Needs review",
            status = "New",
            notes = "Feeling low, mentioned family issues and upcoming board exam anxiety.",
            urgency = "High",
            timestamp = "Today, 10:24 AM"
        ),
        CounsellorCase(
            id = "case_1045",
            studentId = "s6",
            studentName = "Devendra Sen",
            studentClass = "Class 12 - Section B",
            category = "Follow-up requested",
            status = "Under Review",
            notes = "High stress, not sleeping well before practicals.",
            urgency = "Medium",
            timestamp = "Today, 09:12 AM"
        ),
        CounsellorCase(
            id = "case_1087",
            studentId = "s4",
            studentName = "Rohan Verma",
            studentClass = "Class 9 - Section C",
            category = "Conversation requested",
            status = "Scheduled",
            notes = "Selected 'Need some support' on daily check-in. Room 204 session booked.",
            urgency = "Medium",
            timestamp = "Yesterday, 04:33 PM"
        )
    )

    // Helper functions mutating state
    fun submitStudentCheckIn(mood: String, factors: List<String>, wantsToTalk: String) {
        val updated = currentStudent.copy(
            checkedInToday = true,
            streak = currentStudent.streak + 1,
            lastCheckIn = "Today",
            mood = mood
        )
        currentStudent = updated
        studentSeeds += 20

        // Update in student list as well
        val idx = students.indexOfFirst { it.id == currentStudent.id }
        if (idx >= 0) {
            students[idx] = updated
        }

        // Record check-in
        val checkInRecord = CheckIn(
            id = "c_${System.currentTimeMillis()}",
            studentId = currentStudent.id,
            studentName = currentStudent.name,
            studentClass = currentStudent.classSection,
            mood = mood,
            factors = factors,
            wantsToTalk = wantsToTalk,
            timestamp = "Today, Just now"
        )
        checkIns.add(0, checkInRecord)

        // If mood is distressed or wants to talk, alert counsellor
        val needsAttention = mood.contains("Not doing well") || mood.contains("need support") || wantsToTalk == "Yes"
        if (needsAttention) {
            val alertCategory = if (wantsToTalk == "Yes") "Conversation requested" else "Needs review"
            val urgency = if (mood.contains("need support")) "High" else "Medium"
            val newCase = CounsellorCase(
                id = "case_${System.currentTimeMillis() % 10000}",
                studentId = currentStudent.id,
                studentName = currentStudent.name,
                studentClass = currentStudent.classSection,
                category = alertCategory,
                status = "New",
                notes = "Checked in with mood: $mood. Factors: ${factors.joinToString(", ").ifBlank { "General" }}.",
                urgency = urgency,
                timestamp = "Today, Just now"
            )
            counsellorCases.add(0, newCase)
        }
    }

    fun submitFriendReport(
        concernedName: String,
        concernedPhone: String,
        classSection: String,
        concern: String,
        notes: String,
        urgency: String
    ) {
        val report = FriendReport(
            id = "fr_${System.currentTimeMillis() % 10000}",
            reporterId = currentStudent.id,
            reporterName = currentStudent.name,
            concernedName = concernedName,
            concernedPhone = concernedPhone,
            classSection = classSection,
            concern = concern,
            notes = notes,
            urgency = urgency,
            status = "New",
            timestamp = "Today, Just now"
        )
        friendReports.add(0, report)

        val newCase = CounsellorCase(
            id = "case_${System.currentTimeMillis() % 10000}",
            studentId = "peer_${System.currentTimeMillis() % 1000}",
            studentName = concernedName,
            studentClass = classSection,
            category = "Concern reported",
            status = "New",
            notes = "Reported by peer: $concern. Notes: $notes",
            urgency = urgency,
            timestamp = "Today, Just now"
        )
        counsellorCases.add(0, newCase)
    }

    fun submitSupportRequest(type: String, notes: String) {
        val request = SupportRequest(
            id = "sr_${System.currentTimeMillis() % 10000}",
            studentId = currentStudent.id,
            studentName = currentStudent.name,
            studentClass = currentStudent.classSection,
            type = type,
            notes = notes,
            status = "New",
            timestamp = "Today, Just now"
        )
        supportRequests.add(0, request)

        val newCase = CounsellorCase(
            id = "case_${System.currentTimeMillis() % 10000}",
            studentId = currentStudent.id,
            studentName = currentStudent.name,
            studentClass = currentStudent.classSection,
            category = "Follow-up requested",
            status = "New",
            notes = "Requested: $type. Note: $notes",
            urgency = "Medium",
            timestamp = "Today, Just now"
        )
        counsellorCases.add(0, newCase)
    }

    fun updateCaseStatus(caseId: String, newStatus: String, addedNotes: String? = null) {
        val idx = counsellorCases.indexOfFirst { it.id == caseId }
        if (idx >= 0) {
            val old = counsellorCases[idx]
            val updatedNotes = if (!addedNotes.isNullOrBlank()) "${old.notes} | $addedNotes" else old.notes
            counsellorCases[idx] = old.copy(status = newStatus, notes = updatedNotes)
        }
    }

    fun updateFriendReportStatus(reportId: String, newStatus: String) {
        val idx = friendReports.indexOfFirst { it.id == reportId }
        if (idx >= 0) {
            val old = friendReports[idx]
            friendReports[idx] = old.copy(status = newStatus)
        }
    }

    fun updateSupportRequestStatus(requestId: String, newStatus: String) {
        val idx = supportRequests.indexOfFirst { it.id == requestId }
        if (idx >= 0) {
            val old = supportRequests[idx]
            supportRequests[idx] = old.copy(status = newStatus)
        }
    }

    fun sendChatMessage(userText: String) {
        val trimmed = userText.trim()
        if (trimmed.isEmpty()) return

        val userMsg = ChatMessage(
            id = "msg_${System.currentTimeMillis()}",
            senderName = currentStudent.name.ifBlank { "You" },
            message = trimmed,
            isFromUser = true,
            timestamp = "Today, Just now"
        )
        chatMessages.add(userMsg)

        // Immediate contextual auto-reply
        val autoReplyText = when {
            trimmed.contains("appointment", ignoreCase = true) || trimmed.contains("meet", ignoreCase = true) ->
                "Thank you for asking. Counsellor ${counsellorName} is available at ${schoolInfo.name}. You can also submit an official support request via 'I Need to Talk', and our team will schedule a private consultation."
            trimmed.contains("emergency", ignoreCase = true) || trimmed.contains("help", ignoreCase = true) || trimmed.contains("danger", ignoreCase = true) ->
                "If you or someone else is in immediate distress, please call the School Helpline at ${schoolInfo.phone} or emergency response at 112 immediately."
            trimmed.contains("stress", ignoreCase = true) || trimmed.contains("exam", ignoreCase = true) || trimmed.contains("anxious", ignoreCase = true) ->
                "Exam stress and anxiety are very common and treatable. Check out the 4-7-8 Breathing exercises in our Learn & Cope section, and remember to take short breaks."
            trimmed.contains("friend", ignoreCase = true) ->
                "If you're worried about a friend, you can use the 'Tell us about a friend' feature to submit a confidential report to the counsellor."
            else ->
                "Thank you for reaching out to Sahaaya Well-Being. Your message has been received by the guidance team. Take a deep breath—we are here to support you at ${schoolInfo.name}."
        }

        val botReply = ChatMessage(
            id = "msg_reply_${System.currentTimeMillis()}",
            senderName = "Sahaaya Assistant",
            message = autoReplyText,
            isFromUser = false,
            timestamp = "Today, Just now"
        )
        chatMessages.add(botReply)
    }
}

// ═══════════════════════════════════════
// ROUTING CONSTANTS
// ═══════════════════════════════════════

object Screens {
    const val WELCOME = "welcome"
    const val ROLE_SELECT = "role_select"
    const val STUDENT_LOGIN = "student_login"
    const val COUNSELLOR_LOGIN = "counsellor_login"
    const val COUNSELLOR_SIGNUP = "counsellor_signup"

    // Main App Containers
    const val STUDENT_CONTAINER = "student_container"
    const val COUNSELLOR_CONTAINER = "counsellor_container"

    // Global Subscreens
    const val EMERGENCY = "emergency"
    const val FRIEND_CONCERN_STANDALONE = "friend_concern_standalone"
    const val I_NEED_TO_TALK_STANDALONE = "i_need_to_talk_standalone"
    const val LEARNING_HUB_STANDALONE = "learning_hub_standalone"
    const val CHAT_STANDALONE = "chat_standalone"
    const val SCHOOL_SETUP_STANDALONE = "school_setup_standalone"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SahaayaApp()
        }
    }
}

fun launchEmergencyCall(context: Context, number: String = "112") {
    try {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
        context.startActivity(intent)
    } catch (_: Exception) {
        // Fallback gracefully in test/emulator environment
    }
}

@Composable
fun SahaayaApp() {
    val repository = remember { SahaayaRepository() }
    val backStack = remember { mutableStateListOf(Screens.WELCOME) }

    SahaayaTheme(themeMode = repository.themeMode) {
        Surface(modifier = Modifier.fillMaxSize()) {
            fun navigate(to: String) {
                backStack.add(to)
            }

            fun back() {
                if (backStack.size > 1) {
                    backStack.removeAt(backStack.lastIndex)
                }
            }

            BackHandler(enabled = backStack.size > 1) {
                back()
            }

            when (backStack.lastOrNull() ?: Screens.WELCOME) {
                Screens.WELCOME -> {
                    WelcomeScreen(
                        onGetStarted = { navigate(Screens.ROLE_SELECT) },
                        onDirectStudentLogin = { navigate(Screens.STUDENT_LOGIN) },
                        onDirectCounsellorLogin = { navigate(Screens.COUNSELLOR_LOGIN) }
                    )
                }

                Screens.ROLE_SELECT -> {
                    ChooseRoleScreen(
                        onSelectStudent = { navigate(Screens.STUDENT_LOGIN) },
                        onSelectCounsellor = { navigate(Screens.COUNSELLOR_LOGIN) },
                        onBack = { back() }
                    )
                }

                Screens.STUDENT_LOGIN -> {
                    StudentLoginScreen(
                        repository = repository,
                        onBack = { back() },
                        onLoginSuccess = { studentName, school, classSec ->
                            repository.currentStudent = repository.currentStudent.copy(
                                name = studentName,
                                schoolName = school,
                                classSection = classSec
                            )
                            backStack.clear()
                            backStack.add(Screens.STUDENT_CONTAINER)
                        }
                    )
                }

                Screens.COUNSELLOR_LOGIN -> {
                    CounsellorLoginScreen(
                        repository = repository,
                        onBack = { back() },
                        onNavigateSignUp = { navigate(Screens.COUNSELLOR_SIGNUP) },
                        onLoginSuccess = { email, school ->
                            repository.counsellorEmail = email
                            repository.schoolInfo = repository.schoolInfo.copy(name = school)
                            backStack.clear()
                            backStack.add(Screens.COUNSELLOR_CONTAINER)
                        }
                    )
                }

                Screens.COUNSELLOR_SIGNUP -> {
                    CounsellorSignupScreen(
                        repository = repository,
                        onBack = { back() },
                        onSignUpComplete = {
                            backStack.clear()
                            backStack.add(Screens.COUNSELLOR_CONTAINER)
                        }
                    )
                }

                Screens.STUDENT_CONTAINER -> {
                    StudentMainContainer(
                        repository = repository,
                        onLogout = {
                            backStack.clear()
                            backStack.add(Screens.WELCOME)
                        },
                        onNavigateEmergency = { navigate(Screens.EMERGENCY) },
                        onNavigateFriendConcern = { navigate(Screens.FRIEND_CONCERN_STANDALONE) },
                        onNavigateNeedToTalk = { navigate(Screens.I_NEED_TO_TALK_STANDALONE) },
                        onNavigateLearningHub = { navigate(Screens.LEARNING_HUB_STANDALONE) },
                        onNavigateChat = { navigate(Screens.CHAT_STANDALONE) }
                    )
                }

                Screens.COUNSELLOR_CONTAINER -> {
                    CounsellorMainContainer(
                        repository = repository,
                        onLogout = {
                            backStack.clear()
                            backStack.add(Screens.WELCOME)
                        },
                        onNavigateEmergency = { navigate(Screens.EMERGENCY) }
                    )
                }

                Screens.EMERGENCY -> {
                    EmergencyScreen(
                        repository = repository,
                        onBack = { back() }
                    )
                }

                Screens.FRIEND_CONCERN_STANDALONE -> {
                    FriendConcernScreen(
                        repository = repository,
                        onBack = { back() }
                    )
                }

                Screens.I_NEED_TO_TALK_STANDALONE -> {
                    INeedToTalkScreen(
                        repository = repository,
                        onBack = { back() },
                        onOpenChat = { navigate(Screens.CHAT_STANDALONE) }
                    )
                }

                Screens.LEARNING_HUB_STANDALONE -> {
                    LearningHubScreen(
                        onBack = { back() }
                    )
                }

                Screens.CHAT_STANDALONE -> {
                    ChatScreen(
                        repository = repository,
                        onBack = { back() }
                    )
                }

                Screens.SCHOOL_SETUP_STANDALONE -> {
                    SchoolSetupScreen(
                        repository = repository,
                        onLogout = {
                            backStack.clear()
                            backStack.add(Screens.WELCOME)
                        }
                    )
                }
            }
        }
    }
}
